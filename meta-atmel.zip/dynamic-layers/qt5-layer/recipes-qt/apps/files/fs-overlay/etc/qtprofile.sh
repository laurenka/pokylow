export QMLSCENE_DEVICE=softwarecontext
export QT_QPA_PLATFORM=linuxfb
export QT_QPA_FB_DRM=1
export QT_QPA_FB_DRM_FORMAT=6
